const viewCopy = {
  overview: {title:"Cyber Overview", crumb:"Overview", subtitle:"Pusat kendali untuk observasi, analisis, dan pengelolaan keamanan dalam satu workspace."},
  recon: {title:"Recon Center", crumb:"Recon Center", subtitle:"Ruang kerja untuk inventarisasi aset dan pengumpulan informasi yang diizinkan."},
  network: {title:"Network Map", crumb:"Network Map", subtitle:"Area visualisasi topologi jaringan dan hubungan antar-aset."},
  vulnerabilities: {title:"Vulnerability Lab", crumb:"Vulnerability Lab", subtitle:"Workspace untuk pencatatan temuan dan assessment pada sistem yang memiliki izin."},
  terminal: {title:"Terminal", crumb:"Terminal", subtitle:"Area terminal akan tersedia di tahap implementasi berikutnya."},
  reports: {title:"Report Builder", crumb:"Reports", subtitle:"Pusat dokumentasi, ringkasan temuan, dan ekspor laporan."},
  assets: {title:"Asset Inventory", crumb:"Asset Inventory", subtitle:"Inventaris aset dan metadata lingkungan yang terdaftar."},
  activity: {title:"Activity Log", crumb:"Activity Log", subtitle:"Riwayat aktivitas dan perubahan pada workspace."}
};
const navItems = [...document.querySelectorAll("[data-view]")];
const title = document.getElementById("pageTitle");
const subtitle = document.getElementById("pageSubtitle");
const crumb = document.getElementById("crumbTitle");
const sidebar = document.getElementById("sidebar");
const toast = document.getElementById("toast");
let toastTimer;

function showToast(message = "Ini masih fondasi tampilan. Fungsi akan ditambahkan nanti.") {
  const small = toast.querySelector("small");
  small.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3400);
}
function openView(view) {
  const data = viewCopy[view];
  if (!data) return;
  title.innerHTML = data.title === "Cyber Overview" ? 'Cyber <span>Overview</span>' : data.title;
  subtitle.textContent = data.subtitle;
  crumb.textContent = data.crumb;
  document.querySelectorAll(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.view === view));
  sidebar.classList.remove("open");
  if (view !== "overview") showToast(`Modul ${data.crumb} belum aktif. Area fungsi disiapkan untuk tahap berikutnya.`);
}
navItems.forEach(el => el.addEventListener("click", () => openView(el.dataset.view)));
document.getElementById("mobileMenu").addEventListener("click", () => sidebar.classList.toggle("open"));
document.getElementById("dismissNotice").addEventListener("click", () => document.querySelector(".notice-bar").remove());
document.getElementById("newScanButton").addEventListener("click", () => showToast("Assessment belum tersedia. Tambahkan validasi izin dan integrasi backend saat implementasi."));
document.getElementById("exportButton").addEventListener("click", () => showToast("Ekspor laporan belum dihubungkan."));
document.getElementById("closeToast").addEventListener("click", () => toast.classList.remove("show"));
document.getElementById("dateLabel").textContent = new Date().toLocaleDateString("id-ID", {day:"2-digit", month:"short", year:"numeric"}).toUpperCase() + " · LOCAL";
document.addEventListener("keydown", e => {
  if (e.key === "Escape") { sidebar.classList.remove("open"); toast.classList.remove("show"); }
});
