# NEXORA Cyber Lab — UI Foundation

Dashboard frontend bertema cybersecurity dengan tampilan dark-mode profesional dan responsif.

## Isi project
- `index.html` — struktur halaman dashboard.
- `styles.css` — styling, layout responsif, kartu statistik, chart placeholder, tabel, dan komponen.
- `app.js` — navigasi antarmuka dan notifikasi placeholder. Tidak menjalankan pemindaian atau operasi keamanan nyata.

## Menjalankan secara lokal
Buka `index.html` di browser, atau jalankan server lokal:
```bash
python -m http.server 8000
```
Lalu buka `http://localhost:8000`.

## Deploy ke Vercel
1. Buat repository Git dan unggah ketiga file utama (`index.html`, `styles.css`, `app.js`) serta `vercel.json`.
2. Di Vercel, pilih **Add New → Project** dan impor repository.
3. Framework Preset: **Other**. Build Command dan Output Directory dapat dikosongkan untuk static site.
4. Klik **Deploy**.

## Catatan implementasi
Ini sengaja hanya fondasi frontend. Angka, grafik, temuan, dan skor masih placeholder; tombol hanya menampilkan pemberitahuan. Sebelum menambahkan fungsi, tentukan ruang lingkup yang sah, autentikasi, validasi target yang diizinkan, audit log, rate limiting, dan penyimpanan secret di server. Jangan menaruh API key di frontend.
